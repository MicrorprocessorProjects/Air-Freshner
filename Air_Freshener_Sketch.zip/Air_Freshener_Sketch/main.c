#include <msp430.h> 

/*
 * main.c
 */
#define OFF 1

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer

    int R5_SW=0, R6_LED=0, temp=0, SHORT=0, MEDIUM=0, LONG=0;

    P1OUT = 0b00000000;
    P1DIR = 0b11111111;
    P2DIR = 0b00000000;
    P1IE = 0x08;



    while (1)
    {
        // read all switches and save them in R5_SW
	R5_SW = P2IN;
	
	// check for read mode
        if (R5_SW & BIT0)
          {
            R6_LED &= R5_SW | ~(BIT1 + BIT2 + BIT3 + BIT4 + BIT5); // Low Power Mode
            P1OUT |= R6_LED;
          }
        else
        	{
        	if (R5_SW & BIT1)
	          {
	    	   R6_LED |= R5_SW | (BIT1 + BIT2);
	    	   SHORT = BIT3;
			   P1OUT = R6_LED;
			   __delay_cycles(50000); // SHORT spray blinks fast to indicate short spray cycle
			   P1OUT ^= (SHORT);
			   __delay_cycles(50000);
               }
        	else
        	{
        		if (R5_SW & BIT2)
        		{
        		 R6_LED |= R5_SW | (BIT1 + BIT2);
        		 MEDIUM = BIT4;
        		 P1OUT = R6_LED;
        		 __delay_cycles(200000); // MEDIUM spray blinks every second to indicate medium spray cycle
        		 P1OUT ^= (MEDIUM);
        		 __delay_cycles (200000);
        		}
        		else
        		{
        			if (R5_SW & BIT5)
        			{
        				R6_LED |= R5_SW | (BIT1 + BIT2);
        				LONG = BIT5;
        				P1OUT = R6_LED;
        				__delay_cycles(400000); // LONG spray blinks really slow to indicate long spray cycle
        				P1OUT ^= (LONG);
        				__delay_cycles(400000);
        			}
        			else {R6_LED ^= 0xFF; }
        		}

        	}


	    // mask any excessive bits of the pattern and send it out
	    R6_LED &= 0x00;				// help clear all bits beyound the byte so when you rotate you do not see garbage coming in
            P1OUT = R6_LED;
          }
    }
}
